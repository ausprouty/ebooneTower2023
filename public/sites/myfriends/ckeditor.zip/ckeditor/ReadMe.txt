Copy the Styles.js file to

node_modules/ckeditor/styles